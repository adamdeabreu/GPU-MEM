#ifndef i_guard
#define i_guard
#include <complex>
_CL_CUDA_DEVICE_ void txxxxx(double p[4],double tmass,int nhel,int nst,std::complex<double> fi[18]);
#endif
