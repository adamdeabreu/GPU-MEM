#ifndef s_guard
#define s_guard
#include <complex>
_CL_CUDA_DEVICE_ void sxxxxx(double p[4],int nss,std::complex<double> sc[3]);
#endif
