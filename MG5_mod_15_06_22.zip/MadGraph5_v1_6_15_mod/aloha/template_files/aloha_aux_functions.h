#ifndef aloha_aux_functions_guard
#define aloha_aux_functions_guard
_CL_CUDA_DEVICE_ double Sgn(double e,double f);
#endif
