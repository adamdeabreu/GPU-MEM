#include <complex>
#include <cmath>
#include "aloha_aux_functions.h"

_CL_CUDA_DEVICE_ void sxxxxx(double p[4],int nss, std::complex<double> sc[3]){
  sc[2] = std::complex<double>(1.00,0.00);
  sc[0] = std::complex<double>(p[0]*nss,p[3]*nss);
  sc[1] = std::complex<double>(p[1]*nss,p[2]*nss);
  return;
}
